# Plano de testes para o Astra / ChatGPT Work

**Projeto:** Expo Horários — Escola Exponencial. **Meta:** avaliar a versão do site antes da publicação. O Work pode abrir, inspecionar e executar o projeto, sem modificar a matriz de referência nem publicar dados pessoais sem autorização.

## Instrução pronta para o Astra

> Analise o projeto web desta pasta, execute os testes automatizados com `npm test`, suba um servidor HTTP local e valide a interface no desktop e no celular. Confirme os requisitos e registre, em ordem de gravidade, cada bug com instruções de reprodução e evidências. Não publique em um GitHub público nem configure regras abertas do Firestore. Preserve os 305 horários iniciais e prefira usar cópias de dados para testes destrutivos. Dê prioridade a conflitos de professor entre Fundamental II e Ensino Médio, bloqueio por saldos, cargas por turma, horários indisponíveis e retorno seguro de rascunhos. Se encontrar erros, corrija no código, reexecute os testes e informe precisamente o que foi alterado.

## Critérios de aceitação

1. Ao abrir pela primeira vez, apresentar 11 turmas, 22 professores, 305 aulas semanais, com 125 aulas FII e 180 EM.
2. A grade inicial apresentar 5 períodos/dia no Fundamental II, 6 no Médio, sem conflitos e com status concluído.
3. Ao alternar Fundamental II / Médio nas colunas de disciplinas e professores, as tabelas mostrarem os componentes e a atribuição correspondente.
4. Ao editar carga horária de **uma turma**, mostrar total anterior/novo, atribuídas e saldo resultante. Se houver saldo diferente de 0 ou capacidade por turma divergente, desabilitar **Gerar horários**.
5. Ao reduzir a carga abaixo da atribuição, exibir saldo negativo em vermelho; exclusão de atribuição deve atualizar saldos, sem alterar o total do componente.
6. Após ajuste de carga, mostrar **Precisa de atualização**; a versão anterior permanece disponível no histórico.
7. Ao incluir um professor, evitar nomes duplicados; permitir docência em disciplinas e segmentos diferentes sem duplicar identidade.
8. Ao marcar indisponibilidade em um período ocupado, destacar problema até que a geração encontre um encaixe válido (ou retorne rascunho).
9. Ao trocar uma aula manualmente para coincidir com professor em outra turma, marcar **ambas** as células em vermelho e indicar a outra turma.
10. Um horário que não encontrar solução não pode ser declarado concluído, e as posições faltantes ficam em branco; a 6ª aula do Fundamental II fica cinza/inativa por padrão.
11. Exercitar `Gerar horários` após bloquear aulas em posições conflitantes; o sistema deve rejeitar o caso em vez de violar bloqueios.
12. Validar exportação e importação do backup JSON, incluindo cotas, períodos, disponibilidade, grade, revisão e histórico; validar CSV e impressão dos dois segmentos.
13. Validar layout responsivo, foco de teclado, abertura/fechamento de janelas, entrada com acentos e caracteres especiais nos nomes, além da ausência de erros no console.
14. Testar `Firebase Authentication` e regras privadas do Firestore somente em um **projeto de teste** configurado. Validar isolamento de dados entre duas contas diferentes.
15. Confirmar que o repositório público não expõe dados ou backups não autorizados; evitar publicar o arquivo de base real até decisão da escola.

## Observações para o revisor

- A matriz vem dos PDFs de setembro/2026; não é uma matriz oficial validada. O Fundamental I/tarde não foi modelado.
- O resolvedor atual é **heurístico**, não completo: se não encontrar uma grade, retornar rascunho, nunca declarar inviabilidade sem demonstração.
- As aulas especiais (`Biologia A`, `Química A`, `LIV`, `E. Alimentos`, etc.) são intencionalmente tratadas como componentes distintos.
- Uma identidade visual em texto **#eusou EXPO** substitui provisoriamente o arquivo oficial da marca. Caso haja um logo SVG/PNG autorizado, trocar a marca textual pelo arquivo oficial.
