import {allSlots,slotKey,assignedJobs,analyzeSchedule,getClass,validateSetup,clone} from './core.js';
const keyOf=x=>`${x.classId}:${x.day}:${x.period}`;
const randomInt=n=>Math.floor(Math.random()*n);
function viability(s){
 const issues=[],byTeacher=new Map();
 for(const a of s.assignments)byTeacher.set(a.teacherId,(byTeacher.get(a.teacherId)||0)+a.count);
 const allKeys=new Set(s.classes.flatMap(c=>allSlots(c).map(x=>x.key)));
 for(const [id,load] of byTeacher){const blocked=new Set(s.availability?.[id]||[]);const available=[...allKeys].filter(x=>!blocked.has(x)).length;
   if(load>available)issues.push(`${s.teachers.find(p=>p.id===id)?.name}: ${load} aulas para apenas ${available} horários disponíveis (limite comprovado).`);
 }
 return issues;
}
export function generateSchedule(s,{iterations=100000,maxMs=7000}={}){
 const setup=validateSetup(s);if(!setup.valid)return {solved:false,blocked:true,messages:setup.errors};
 const impossible=viability(s);if(impossible.length)return {solved:false,blocked:true,messages:impossible};
 const jobs=assignedJobs(s),jobsMap=new Map(jobs.map(j=>[j.id,j]));
 const current=analyzeSchedule(s);if(current.complete && s.schedule.length===jobs.length)return {solved:true,schedule:clone(s.schedule),pending:[],messages:['A grade já atende às restrições; a distribuição foi preservada.']};
 const positions=[];const perClass=new Map();
 for(const c of s.classes){const range=[];for(const v of allSlots(c)){range.push(positions.length);positions.push({classId:c.id,day:v.day,period:v.period});}perClass.set(c.id,range)}
 const lockedLessons=s.schedule.filter(x=>x.locked);const lockedConflicts=analyzeSchedule(s,lockedLessons).conflicts;if(lockedConflicts.size)return {solved:false,blocked:true,messages:['Existem aulas travadas com conflito, indisponibilidade ou fora da grade. Corrija os bloqueios antes de gerar.']};
 const locks=new Map();for(const e of lockedLessons){if(!jobsMap.has(e.jobId))return {solved:false,blocked:true,messages:[`Aula travada ${e.id} já não corresponde às cotas. Destrave ou ajuste a atribuição.`]};const key=keyOf(e);if(locks.has(key))return {solved:false,blocked:true,messages:['Há mais de uma aula travada na mesma posição.']};locks.set(key,e.jobId)}
 const slotMap=new Map(positions.map((p,i)=>[keyOf(p),i]));const fixed=new Set();const base=new Array(positions.length).fill(null);const used=new Set();
 for(const [key,jid] of locks){const ix=slotMap.get(key);if(ix===undefined)return {solved:false,blocked:true,messages:['Existe uma aula travada fora da nova grade.']};if(used.has(jid))return {solved:false,blocked:true,messages:['Uma aula travada está duplicada.']};used.add(jid);fixed.add(ix);base[ix]=jobsMap.get(jid)}
 const availableById=new Map(jobs.filter(j=>!used.has(j.id)).map(j=>[j.id,j]));
 for(const old of s.schedule){const idx=slotMap.get(keyOf(old));if(idx===undefined||fixed.has(idx)||base[idx])continue;const j=availableById.get(old.jobId);if(!j||j.classId!==positions[idx].classId)continue;base[idx]=j;availableById.delete(j.id)}
 const loose=[...availableById.values()];
 for(const c of s.classes){const free=perClass.get(c.id).filter(ix=>!base[ix]);const candidates=loose.filter(j=>j.classId===c.id);if(candidates.length!==free.length)return {solved:false,blocked:true,messages:[`Inconsistência interna nas aulas da ${c.name}.`]};for(let k=0;k<free.length;k++)base[free[k]]=candidates[k]}
 const blocked=new Map(Object.entries(s.availability||{}).map(([t,slots])=>[t,new Set(slots)]));
 function cost(items){const concurrent=new Map();let penalty=0;
  for(let i=0;i<items.length;i++){
   const j=items[i],p=positions[i];if(!j)continue;
   const k=`${j.teacherId}|${p.day}|${p.period}`,count=concurrent.get(k)||0;
   if(count)penalty+=100*count;
   concurrent.set(k,count+1);
   if(blocked.get(j.teacherId)?.has(slotKey(p.day,p.period)))penalty+=100;
  }
  return penalty;
 }
 const freePairs=[...perClass.values()].map(list=>list.filter(ix=>!fixed.has(ix))).filter(list=>list.length>=2);
 let currentItems=base.slice(), curCost=cost(currentItems),bestItems=currentItems.slice(),bestCost=curCost;
 const start=Date.now();let steps=0;
 while(steps<iterations && Date.now()-start<maxMs && bestCost>0 && freePairs.length){
   steps++;
   const list=freePairs[randomInt(freePairs.length)];const a=randomInt(list.length),b=randomInt(list.length);if(a===b)continue;
   const i=list[a],j=list[b];if(currentItems[i].teacherId===currentItems[j].teacherId)continue;
   [currentItems[i],currentItems[j]]=[currentItems[j],currentItems[i]];
   const next=cost(currentItems),delta=next-curCost;
   const temp=Math.max(1,(1-(steps%25000)/25000)*16);
   if(delta<=0||Math.random()<Math.exp(-delta/temp)){curCost=next;if(curCost<bestCost){bestCost=curCost;bestItems=currentItems.slice();}}
   else [currentItems[i],currentItems[j]]=[currentItems[j],currentItems[i]];
   if(steps%25000===0){currentItems=bestItems.slice();curCost=bestCost;
     for(let k=0;k<Math.min(25,freePairs.length*3);k++){
      const li=freePairs[randomInt(freePairs.length)];const ia=li[randomInt(li.length)],ib=li[randomInt(li.length)];[currentItems[ia],currentItems[ib]]=[currentItems[ib],currentItems[ia]];
     }
     curCost=cost(currentItems);
   }
 }
 const assembled=bestItems.map((job,i)=>({id:`G${String(i+1).padStart(3,'0')}`,classId:positions[i].classId,day:positions[i].day,period:positions[i].period,assignmentId:job.assignmentId,jobId:job.id,teacherId:job.teacherId,subject:job.subject,locked:fixed.has(i)}));
 if(bestCost===0){return {solved:true,schedule:assembled,pending:[],steps,messages:[`Distribuição completa sem choques ou indisponibilidades (${steps} tentativas de ajuste).`]}}
 // Safety: an unsuccessful search never returns overlapping teachers as a "complete" grid.
 const filtered=assembled.slice();const occupied=new Map(),removed=[];
 for(const a of assembled){const tk=`${a.teacherId}:${a.day}:${a.period}`;const conflict=occupied.get(tk);const banned=blocked.get(a.teacherId)?.has(slotKey(a.day,a.period));
  if(banned){removed.push({...a,reason:'Professor indisponível'});continue}
  if(conflict){if(conflict.locked&&!a.locked){removed.push({...a,reason:'Choque com aula travada'});continue}
    if(a.locked&&!conflict.locked){removed.push({...conflict,reason:'Choque com aula travada'});occupied.set(tk,a);continue}
    removed.push({...a,reason:'Choque de professor'});continue}
  occupied.set(tk,a);
 }
 const retained=new Set([...occupied.values()].map(e=>e.jobId));
 const schedule=assembled.filter(e=>retained.has(e.jobId));
 const pending=removed.filter(e=>!retained.has(e.jobId));
 return {solved:false,schedule,pending,steps,messages:[`Busca não encontrou uma grade completa após ${steps} tentativas. ${pending.length} aula(s) ficaram pendentes, sem introduzir choques. Isto não comprova inviabilidade.`]};
}
