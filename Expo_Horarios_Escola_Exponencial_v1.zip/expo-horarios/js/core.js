export const DAYS = ['Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira'];
export const PERIODS = ['07:00–07:50','07:50–08:40','08:55–09:45','09:45–10:35','10:50–11:40','11:40–12:30'];
export const SEGMENTS = {FII:'Fundamental II',EM:'Ensino Médio'};
export const clone = x => JSON.parse(JSON.stringify(x));
export const totalSlots = c => c.weeklySlots.reduce((a,b)=>a+b,0);
export const slotKey = (d,p)=>`${d}:${p}`;
export const allSlots = c => c.weeklySlots.flatMap((n,d)=>Array.from({length:n},(_,p)=>({day:d,period:p,key:slotKey(d,p)})));
export const isActive = (c,d,p)=>p>=0 && d>=0 && d<5 && p<(c.weeklySlots[d]||0);
export const getClass = (s,id)=>s.classes.find(c=>c.id===id);
export const getTeacher = (s,id)=>s.teachers.find(p=>p.id===id);
export const disciplines = (s,segment)=>[...new Set(s.classes.filter(c=>c.segment===segment).flatMap(c=>Object.keys(s.matrix[c.id]||{})))].sort((a,b)=>a.localeCompare(b,'pt-BR'));
export const demandFor = (s,seg,subject) => s.classes.filter(c=>c.segment===seg).reduce((a,c)=>a+(Number(s.matrix[c.id]?.[subject])||0),0);
export const assignedFor = (s,seg,subject) => s.assignments.filter(a=>getClass(s,a.classId)?.segment===seg && a.subject===subject).reduce((t,a)=>t+Number(a.count),0);
export const summaryFor = (s,seg)=>disciplines(s,seg).map(subject=>({subject,total:demandFor(s,seg,subject),assigned:assignedFor(s,seg,subject),remaining:demandFor(s,seg,subject)-assignedFor(s,seg,subject)}));
export const scheduleKey = x=>`${x.classId}:${x.day}:${x.period}`;
export const assignedJobs = s => s.assignments.flatMap(a=>Array.from({length:Number(a.count)||0},(_,i)=>({id:`${a.id}:${i+1}`,assignmentId:a.id,classId:a.classId,teacherId:a.teacherId,subject:a.subject})));

export function validateSetup(s){
 const errors=[], warnings=[]; const teachers=new Set(s.teachers.map(x=>x.id));const classes=new Set(s.classes.map(x=>x.id));
 const assignmentKeys=new Set();
 for(const c of s.classes){
   if(!Array.isArray(c.weeklySlots) || c.weeklySlots.length!==5 || c.weeklySlots.some(v=>!Number.isInteger(v)||v<0||v>PERIODS.length)) errors.push(`Períodos inválidos: ${c.name}.`);
   const total=Object.values(s.matrix[c.id]||{}).reduce((t,n)=>t+Number(n),0);
   if(total!==totalSlots(c)) errors.push(`${c.name}: matriz tem ${total} aulas, mas a grade comporta ${totalSlots(c)}.`);
   if(Object.values(s.matrix[c.id]||{}).some(n=>!Number.isInteger(n)||n<0))errors.push(`${c.name}: cargas de disciplina inválidas.`);
 }
 for(const a of s.assignments){
   if(!teachers.has(a.teacherId) || !classes.has(a.classId)) errors.push(`Atribuição ${a.id}: professor ou turma ausente.`);
   if(!Number.isInteger(a.count)||a.count<=0) errors.push(`Atribuição ${a.id}: quantidade inválida.`);
   if(!(a.subject in (s.matrix[a.classId]||{})))errors.push(`Atribuição ${a.id}: disciplina não existe na matriz da turma.`);
   const key=`${a.classId}|${a.subject}|${a.teacherId}`;
   if(assignmentKeys.has(key)) errors.push(`Atribuição duplicada: ${key}.`);
   assignmentKeys.add(key);
 }
 for(const c of s.classes){
   for(const [subject,required] of Object.entries(s.matrix[c.id]||{})){
     const assigned=s.assignments.filter(a=>a.classId===c.id&&a.subject===subject).reduce((t,a)=>t+a.count,0);
     if(required!==assigned) errors.push(`${c.name} / ${subject}: ${required} necessárias, ${assigned} atribuídas (${required-assigned} de saldo).`);
   }
 }
 for(const t of s.teachers){
   if(!t.name?.trim())errors.push(`Professor sem nome (${t.id}).`);
 }
 if(s.classes.some(c=>c.segment==='FII')&&s.classes.some(c=>c.segment==='EM'))warnings.push('A disponibilidade fora das turmas matutinas cadastradas deve ser informada manualmente.');
 return {errors,warnings,valid:errors.length===0};
}

export function analyzeSchedule(s, entries=s.schedule){
 const items=entries||[];const conflicts=new Map();const errors=[];const classTime=new Map();const teacherTime=new Map();const unavailable=[];const offGrid=[];
 const add=(id,msg)=>{if(!conflicts.has(id))conflicts.set(id,[]);if(!conflicts.get(id).includes(msg))conflicts.get(id).push(msg)};
 for(const e of items){
   const c=getClass(s,e.classId); const t=getTeacher(s,e.teacherId);
   if(!c||!t){errors.push('Aula com turma/professor não cadastrado.');continue}
   if(!isActive(c,e.day,e.period)){offGrid.push(e);add(e.id,'Aula fora da grade configurada.');}
   if((s.availability?.[e.teacherId]||[]).includes(slotKey(e.day,e.period))){ unavailable.push(e);add(e.id,`${t.name} indisponível neste horário.`); }
   const ck=scheduleKey(e),tk=`${e.teacherId}:${e.day}:${e.period}`;
   if(!classTime.has(ck))classTime.set(ck,[]);classTime.get(ck).push(e);
   if(!teacherTime.has(tk))teacherTime.set(tk,[]);teacherTime.get(tk).push(e);
 }
 for(const set of classTime.values())if(set.length>1)for(const x of set)for(const y of set)if(x!==y)add(x.id,`Choque de turma com ${y.subject} (${getTeacher(s,y.teacherId)?.name||'?'}).`);
 for(const set of teacherTime.values())if(set.length>1)for(const x of set)for(const y of set)if(x!==y)add(x.id,`Choque de professor com ${getClass(s,y.classId)?.name||'outra turma'} (${DAYS[y.day]}, ${PERIODS[y.period]}).`);
 const byAssignment=new Map();for(const e of items)byAssignment.set(e.assignmentId,(byAssignment.get(e.assignmentId)||0)+1);
 for(const a of s.assignments){const qty=byAssignment.get(a.id)||0;if(qty!==a.count)errors.push(`${getClass(s,a.classId)?.name||'?'} / ${a.subject} / ${getTeacher(s,a.teacherId)?.name||'?'}: ${a.count} previstas, ${qty} posicionadas.`)}
 const filled=new Set(items.filter(e=>isActive(getClass(s,e.classId)||{weeklySlots:[0,0,0,0,0]},e.day,e.period)).map(scheduleKey));
 const missing=s.classes.flatMap(c=>allSlots(c).filter(sl=>!filled.has(`${c.id}:${sl.key}`)).map(sl=>({classId:c.id,day:sl.day,period:sl.period})));
 return {conflicts,errors,unavailable,offGrid,missing,complete:conflicts.size===0&&errors.length===0&&missing.length===0&&validateSetup(s).valid};
}
export function validationReport(s){const setup=validateSetup(s);const grid=analyzeSchedule(s);return {setup,grid,stale:s.dataRevision!==s.scheduleRevision,complete:setup.valid&&grid.complete&&s.dataRevision===s.scheduleRevision}}
export function markChanged(s){s.dataRevision=(s.dataRevision||1)+1;s.scheduleStatus='desatualizado';s.updatedAt=new Date().toISOString();}
export function takeSnapshot(s,label){s.history=s.history||[];s.history.unshift({timestamp:new Date().toISOString(),label,dataRevision:s.dataRevision,scheduleRevision:s.scheduleRevision, schedule:clone(s.schedule),matrix:clone(s.matrix),assignments:clone(s.assignments),classes:clone(s.classes),teachers:clone(s.teachers),availability:clone(s.availability||{})});s.history=s.history.slice(0,12)}
export function validateImport(s){if(!s||s.schemaVersion!==1||!Array.isArray(s.classes)||!Array.isArray(s.teachers)||!Array.isArray(s.assignments)||!Array.isArray(s.schedule)||typeof s.matrix!=='object')throw new Error('Arquivo incompatível: formato ou campos obrigatórios ausentes.');if(s.classes.length>200||s.schedule.length>10000||s.assignments.length>10000)throw new Error('Arquivo grande demais para esta versão.');return s}
