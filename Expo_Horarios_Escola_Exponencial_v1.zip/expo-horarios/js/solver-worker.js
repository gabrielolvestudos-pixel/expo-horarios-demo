import {generateSchedule} from './scheduler.js';
self.addEventListener('message',ev=>{
 try{self.postMessage({ok:true,result:generateSchedule(ev.data.state,ev.data.options||{})});}
 catch(err){self.postMessage({ok:false,error:err.message||String(err)});}
});
