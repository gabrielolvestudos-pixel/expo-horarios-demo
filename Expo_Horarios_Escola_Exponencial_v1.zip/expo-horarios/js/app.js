import {DAYS,PERIODS,SEGMENTS,clone,totalSlots,allSlots,isActive,getClass,getTeacher,disciplines,summaryFor,validateSetup,analyzeSchedule,validationReport,markChanged,takeSnapshot,validateImport,assignedJobs} from './core.js';
import {createCloud} from './firebase-sync.js';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n).toLocaleString('pt-BR');
const storageKey='expo.horarios.2026.v1';
let state,seed,cloud=null,discSegment='FII',teacherSegment='FII',lastPending=[],isSolving=false,modalSubmit=null,toastTimer;
const teacherName=id=>getTeacher(state,id)?.name||'Não cadastrado';
const className=id=>getClass(state,id)?.name||'Turma desconhecida';
const segmentLabel=seg=>SEGMENTS[seg]||seg;
const totalDemand=()=>Object.values(state.matrix).flatMap(v=>Object.values(v)).reduce((n,v)=>n+Number(v),0);
function notify(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),4400)}
function store(){try{localStorage.setItem(storageKey,JSON.stringify(state));$('saveIndicator').innerHTML='<span class="saved-dot"></span>Salvo neste navegador';cloud?.save();}catch(e){$('saveIndicator').textContent='Erro ao salvar localmente';notify('Não foi possível salvar: '+e.message)}}
function afterEdit(message){markChanged(state);lastPending=[];store();renderAll();notify(message)}
function confirmAction(message){return window.confirm(message)}
function showModal(title,body,onSubmit,{submitLabel='Salvar alterações',cancelLabel='Cancelar',noSubmit=false}={}){
 $('modalTitle').textContent=title;$('modalBody').oninput=null;$('modalBody').innerHTML=body;modalSubmit=onSubmit;
 $('modalFoot').innerHTML=`<button type="button" class="smallbtn outline" id="cancelModal">${esc(cancelLabel)}</button>${noSubmit?'':`<button type="submit" class="primary">${esc(submitLabel)}</button>`}`;
 $('cancelModal').onclick=()=>closeModal();$('modal').showModal();
}
function closeModal(){$('modal').close();modalSubmit=null}
$('modalClose').onclick=closeModal;
$('modalForm').addEventListener('submit',e=>{e.preventDefault();if(!modalSubmit)return;try{modalSubmit(new FormData($('modalForm')));}catch(err){notify(err.message||String(err));}});
function renderStats(){const sum=[...summaryFor(state,'FII'),...summaryFor(state,'EM')];
 const abs=sum.reduce((t,r)=>t+Math.abs(r.remaining),0), invalid=sum.filter(r=>r.remaining!==0).length;
 const cards=[['Turmas ativas',state.classes.length,'Fundamental II + Médio','▦'],['Professores',state.teachers.length,'Cadastro compartilhado','♙'],['Aulas semanais',totalDemand(),'Matriz curricular vigente','◷'],['Saldos a corrigir',abs,invalid?`${invalid} componente(s) desbalanceado(s)`:'Todas as cotas conferidas',invalid?'!':'✓']];
 $('statsGrid').innerHTML=cards.map(([name,value,sub,icon])=>`<div class="stat"><div class="stat-copy"><span class="stat-name">${esc(name)}</span><span class="stat-value">${fmt(value)}</span><span class="stat-sub">${esc(sub)}</span></div><span class="stat-icon">${icon}</span></div>`).join('');
}
function renderAlerts(report){const errors=report.setup.errors;
 const arr=[];
 if(errors.length)arr.push(`<div class="alert error"><strong>Há ${errors.length} pendência(s) de configuração. A geração está bloqueada.</strong><ul>${errors.slice(0,6).map(e=>`<li>${esc(e)}</li>`).join('')}${errors.length>6?`<li>… e mais ${errors.length-6} pendência(s).</li>`:''}</ul></div>`);
 if(report.stale)arr.push('<div class="alert warn"><strong>Horário precisa de atualização.</strong> A matriz, as atribuições ou a disponibilidade mudaram. A grade anterior permanece visível como rascunho até uma nova geração e validação.</div>');
 $('alerts').innerHTML=arr.join('');
 $('generateBtn').disabled=isSolving||!report.setup.valid;
 $('generateBtn').textContent=isSolving?'◌ Gerando horários…':'✦ Gerar horários';
 $('generateHint').textContent=report.setup.valid?'Cotas conferidas. A busca pode ser iniciada e verificará os dois segmentos ao mesmo tempo.':'Corrija os saldos e os totais das turmas para liberar a geração.';
}
function renderDisc(){const search=$('discSearch').value.trim().toLocaleLowerCase('pt-BR');const rows=summaryFor(state,discSegment).filter(x=>x.subject.toLocaleLowerCase('pt-BR').includes(search));
 $('discCount').textContent=disciplines(state,discSegment).length+' componentes';
 $('discList').innerHTML=rows.map(r=>`<div class="disc-row"><div class="disc-details"><div class="disc-name">${esc(r.subject)}</div><div class="disc-note"><button class="linkedit" data-edit-load="${esc(r.subject)}">✎ Editar carga horária</button></div></div><div class="disc-num"><div class="ministat"><strong>${r.total}</strong><small>Total</small></div><div class="ministat"><strong>${r.assigned}</strong><small>Atrib.</small></div><div class="ministat ${r.remaining<0?'negative':''}"><strong>${r.remaining}</strong><small>Rest.</small></div></div></div>`).join('')||'<div class="empty-list">Nenhuma disciplina encontrada.</div>';
}
function renderTeachers(){const q=$('teacherSearch').value.trim().toLocaleLowerCase('pt-BR');const list=state.teachers.filter(t=>t.name.toLocaleLowerCase('pt-BR').includes(q)&&(t.segments?.includes(teacherSegment)||state.assignments.some(a=>a.teacherId===t.id&&getClass(state,a.classId)?.segment===teacherSegment)));
 $('teacherCount').textContent=list.length+' docentes';
 $('teacherList').innerHTML=list.map(t=>{const assignments=state.assignments.filter(a=>a.teacherId===t.id&&getClass(state,a.classId)?.segment===teacherSegment);const count=assignments.reduce((x,a)=>x+a.count,0);const initials=t.name.split(' ').slice(0,2).map(z=>z[0]).join('').toUpperCase();
  return `<div class="teacher-row"><div class="teacher-head"><div class="avatar">${esc(initials)}</div><div><div class="teacher-name">${esc(t.name)}</div><div class="teacher-meta">${assignments.length} atribuição(ões) neste segmento</div></div><span class="teacher-load">${count} aulas</span></div><div class="teacher-chips">${assignments.map(a=>`<button title="Editar atribuição" data-edit-assignment="${esc(a.id)}" class="teacher-chip">${esc(a.subject)} · ${esc(className(a.classId))} (${a.count}) ✎</button>`).join('')||'<span class="disc-note">Sem atribuições registradas</span>'}</div><div class="teacher-tools"><button class="linkedit" data-edit-teacher="${esc(t.id)}">Editar docente</button></div></div>`;
 }).join('')||'<div class="empty-list">Nenhum professor encontrado.</div>';
}
function renderGrids(report){for(const seg of ['FII','EM']){
 const classes=state.classes.filter(c=>c.segment===seg),target=$(seg==='FII'?'gridFii':'gridEm');let html='';
 const maxPeriods=Math.max(0,...classes.flatMap(c=>c.weeklySlots));
 const cells=new Map();for(const e of state.schedule){const k=`${e.classId}:${e.day}:${e.period}`;if(!cells.has(k))cells.set(k,[]);cells.get(k).push(e)}
 for(let d=0;d<5;d++){
  html+=`<div class="day-block"><div class="day-header"><span>${DAYS[d]}</span><span>Dia ${d+1}/5</span></div><div class="table-scroller"><table class="schedule-table"><thead><tr><th>HORÁRIO</th>${classes.map(c=>`<th>${esc(c.name)}</th>`).join('')}</tr></thead><tbody>`;
  for(let period=0;period<maxPeriods;period++){
    html+=`<tr><th>${period+1}ª aula<br>${esc(PERIODS[period]||'A configurar')}</th>`;
    for(const c of classes){if(!isActive(c,d,period)){html+='<td class="schedule-cell disabled-cell" title="Fora da grade">—</td>';continue}
      const key=`${c.id}:${d}:${period}`,arr=cells.get(key)||[],e=arr[0],problem=arr.some(x=>report.grid.conflicts.has(x.id)),cls=problem?'conflicted':e?'':'pending';
      const tooltip=arr.map(x=>report.grid.conflicts.get(x.id)?.join(' | ')||`${x.subject} / ${teacherName(x.teacherId)}`).join(' | ');
      html+=`<td class="schedule-cell ${cls}" tabindex="0" role="button" aria-label="Editar aula ${esc(c.name)}, ${DAYS[d]}, ${period+1}º horário" title="${esc(tooltip)}" data-cell="${esc(key)}">${e?`<div class="s-subject">${esc(e.subject)}${arr.length>1?' (+'+(arr.length-1)+')':''}</div><div class="s-teacher">${esc(teacherName(e.teacherId))}</div>${e.locked?'<span class="lock-pin">🔒</span>':''}`:'<div class="s-subject">&nbsp;</div>'}</td>`;
    }
    html+='</tr>';
  }
  html+='</tbody></table></div></div>';
 }
 target.innerHTML=html;
 }
 const wasStale=report.stale,hasProblems=report.grid.conflicts.size>0;
 $('scheduleNotice').className='notice '+(report.complete?'good':hasProblems?'bad':'warn');
 $('scheduleNotice').textContent=report.complete?'✓ Horário concluído: cargas, posições, disponibilidade e conflitos validados conjuntamente.':wasStale?'⚠ Precisa de atualização. Esta grade é uma versão anterior; alterações de dados exigem nova geração.':hasProblems?`⚠ Há ${report.grid.conflicts.size} célula(s) com conflito. Elas estão destacadas em vermelho.`:`⚠ Rascunho: ${report.grid.missing.length} posição(ões) vazia(s) ou outras pendências de validação.`;
 const messages=[...lastPending.slice(0,22).map(x=>`${className(x.classId)}, ${DAYS[x.day]}, ${x.period+1}ª aula: ${x.subject} (${teacherName(x.teacherId)}) — ${x.reason}.`),...report.grid.errors.slice(0,10)];
 $('pendingCard').innerHTML=messages.length?`<h3>Pendências e orientações</h3><ul>${messages.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:`<strong>${report.complete?'Nenhuma pendência registrada.':'Verifique a configuração e a grade atual antes de concluir.'}</strong>`;
}
function renderAll(){const report=validationReport(state);renderStats();renderAlerts(report);renderDisc();renderTeachers();renderGrids(report);return report}
function modalLoad(subject){const classes=state.classes.filter(c=>c.segment===discSegment && subject in (state.matrix[c.id]||{}));const origTotal=summaryFor(state,discSegment).find(x=>x.subject===subject);if(!origTotal)return;
 showModal('Editar carga horária · '+subject,`<p class="modal-help">Selecione as turmas que receberão a mesma quantidade semanal. As cotas dos professores <strong>não são alteradas automaticamente</strong>.</p><div class="multi-check">${classes.map((c,i)=>`<label><input type="checkbox" class="load-class" name="classes" value="${esc(c.id)}" ${i===0?'checked':''}> ${esc(c.name)} — atual: <strong>${state.matrix[c.id][subject]}</strong></label>`).join('')}</div><label>Nova carga semanal por turma<input id="loadCount" name="count" type="number" min="0" max="30" value="${state.matrix[classes[0]?.id]?.[subject]??0}" required /></label><div class="preview-totals"><span>Total anterior<strong>${origTotal.total}</strong></span><span>Novo total<strong id="previewNew">${origTotal.total}</strong></span><span>Atribuídas<strong>${origTotal.assigned}</strong></span><span>Saldo previsto<strong id="previewRemaining">${origTotal.remaining}</strong></span></div><p class="modal-hint">A alteração poderá deixar a matriz da turma diferente da sua capacidade semanal. Ajuste também os períodos se o regimento tiver mudado.</p>`,form=>{
 const ids=form.getAll('classes');if(!ids.length)throw Error('Selecione pelo menos uma turma.');const n=Number(form.get('count'));if(!Number.isInteger(n)||n<0||n>30)throw Error('Informe um número inteiro de 0 a 30.');
 takeSnapshot(state,'Antes da edição de carga · '+subject);for(const id of ids)state.matrix[id][subject]=n;
 closeModal();afterEdit('Carga horária atualizada. Confira as cotas e os períodos das turmas.');
 });
 const recalc=()=>{const ids=[...$('modalBody').querySelectorAll('input.load-class:checked')].map(x=>x.value);const newQty=Number($('loadCount').value)||0;const total=origTotal.total+ids.reduce((t,id)=>t+newQty-state.matrix[id][subject],0);$('previewNew').textContent=total;$('previewRemaining').textContent=total-origTotal.assigned; $('previewRemaining').style.color=total-origTotal.assigned<0?'#c93346':'#204e7c'};
 $('modalBody').oninput=recalc;recalc();
}
function modalTeacher(id=null){const t=state.teachers.find(x=>x.id===id);showModal(t?'Editar professor':'Adicionar professor',`<label>Nome do professor<input name="name" type="text" maxlength="90" value="${esc(t?.name||'')}" required placeholder="Nome completo" /></label><p class="modal-help">O cadastro é único por docente, mesmo quando atua em mais de um segmento. O Fundamental I pode ser assinalado para futura expansão.</p><div class="multi-check">${[['FI','Fundamental I'],['FII','Fundamental II'],['EM','Ensino Médio']].map(([k,label])=>`<label><input type="checkbox" name="segments" value="${k}" ${t?.segments?.includes(k)?'checked':''}> ${label}</label>`).join('')}</div>`,form=>{
 const name=String(form.get('name')||'').trim();const segments=form.getAll('segments');if(name.length<2||!segments.length)throw Error('Informe o nome e pelo menos um segmento.');if(state.teachers.some(p=>p.id!==id&&p.name.toLocaleLowerCase('pt-BR')===name.toLocaleLowerCase('pt-BR')))throw Error('Este professor já está cadastrado.');takeSnapshot(state,(t?'Edição':'Cadastro')+' de professor');if(t){t.name=name;t.segments=segments}else state.teachers.push({id:'p'+Date.now().toString(36),name,segments});closeModal();afterEdit('Cadastro de professores atualizado.');
 });
}
function modalAssignment(id=null){const original=state.assignments.find(a=>a.id===id);
 let selectedClass=original?.classId||state.classes.find(c=>c.segment===teacherSegment)?.id||state.classes[0].id;
 const classOptions=state.classes.map(c=>`<option value="${esc(c.id)}" ${selectedClass===c.id?'selected':''}>${esc(c.name)} · ${esc(segmentLabel(c.segment))}</option>`).join('');
 const teacherOptions=state.teachers.map(t=>`<option value="${esc(t.id)}" ${t.id===(original?.teacherId||'')?'selected':''}>${esc(t.name)}</option>`).join('');
 showModal(original?'Editar atribuição':'Nova atribuição',`<p class="modal-help">Vincule o docente a uma turma, disciplina e quantidade semanal. Você poderá distribuir uma mesma disciplina entre vários professores.</p><label>Professor<select name="teacherId" required>${original?'':`<option value="">Selecione…</option>`}${teacherOptions}</select></label><div class="grid-form"><label>Turma<select name="classId" id="assignClass" required>${classOptions}</select></label><label>Disciplina<select name="subject" id="assignSubject" required></select></label></div><label>Aulas semanais atribuídas<input type="number" name="count" min="1" max="30" value="${original?.count??1}" required /></label><p class="modal-hint">As atribuições serão comparadas com a carga oficial de cada componente. Excesso e falta bloqueiam a geração.</p>${original?`<button type="button" id="deleteAssignment" class="smallbtn danger">Excluir esta atribuição</button>`:''}`,form=>{
 const teacherId=String(form.get('teacherId')),classId=String(form.get('classId')),subject=String(form.get('subject')),count=Number(form.get('count'));
 if(!teacherId||!classId||!subject||!Number.isInteger(count)||count<1||count>30)throw Error('Preencha todos os campos com uma carga válida.');
 const collides=state.assignments.some(a=>a.id!==id&&a.teacherId===teacherId&&a.classId===classId&&a.subject===subject);if(collides)throw Error('Já existe uma atribuição idêntica. Edite aquela atribuição.');
 takeSnapshot(state,'Antes da edição de atribuição');if(original)Object.assign(original,{teacherId,classId,subject,count});else state.assignments.push({id:'a'+Date.now().toString(36),teacherId,classId,subject,count});
 const person=getTeacher(state,teacherId),segment=getClass(state,classId)?.segment;if(person&&segment&&!person.segments.includes(segment))person.segments.push(segment);
 closeModal();afterEdit('Atribuição atualizada. Os saldos foram recalculados.');
 });
 const updateSubjects=()=>{const cls=getClass(state,$('assignClass').value);const items=Object.keys(state.matrix[cls.id]||{}).filter(name=>state.matrix[cls.id][name]>0);$('assignSubject').innerHTML=items.map(sub=>`<option value="${esc(sub)}" ${original?.subject===sub?'selected':''}>${esc(sub)}</option>`).join('')};
 $('assignClass').addEventListener('change',updateSubjects);updateSubjects();
 if(original)$('deleteAssignment').addEventListener('click',()=>{if(!confirmAction('Excluir esta atribuição? A carga da disciplina ficará pendente até ser redistribuída.'))return;takeSnapshot(state,'Antes da exclusão de atribuição');state.assignments=state.assignments.filter(a=>a.id!==id);closeModal();afterEdit('Atribuição excluída.');});
}
function modalWeeklySlots(){showModal('Aulas e períodos por turma',`<p class="modal-help">A quantidade de aulas por dia define os horários disponíveis. O total semanal da turma é a soma dos cinco dias. Os horários-base vão da 1ª à 6ª aula, conforme os PDFs de referência.</p><label>Turma<select id="configClass">${state.classes.map(c=>`<option value="${esc(c.id)}">${esc(c.name)} — ${esc(segmentLabel(c.segment))}</option>`).join('')}</select></label><div class="grid-form" id="daysConfig"></div><p class="modal-hint" id="weeklyPreview"></p>`,form=>{
 const c=getClass(state,$('configClass').value),values=DAYS.map((_,i)=>Number(form.get('period'+i)));
 if(values.some(n=>!Number.isInteger(n)||n<0||n>PERIODS.length))throw Error('Os dias precisam de 0 a 6 aulas.');takeSnapshot(state,'Antes de alterar períodos · '+c.name);c.weeklySlots=values;closeModal();afterEdit(`Grade de ${c.name} atualizada (${totalSlots(c)} aulas semanais).`);
 });
 const draw=()=>{const c=getClass(state,$('configClass').value);$('daysConfig').innerHTML=DAYS.map((d,i)=>`<label>${d}<input type="number" min="0" max="6" name="period${i}" value="${c.weeklySlots[i]}" required /></label>`).join('');const preview=()=>{$('weeklyPreview').textContent=`Capacidade: ${DAYS.reduce((x,_,i)=>x+(Number($('modalForm').elements['period'+i]?.value)||0),0)} aulas por semana. Matriz curricular atual: ${Object.values(state.matrix[c.id]||{}).reduce((t,n)=>t+n,0)}.`};$('daysConfig').oninput=preview;preview()};
 $('configClass').addEventListener('change',draw);draw();
}
function modalAvailability(){const chosen=state.teachers[0]?.id;showModal('Disponibilidade dos professores',`<p class="modal-help"><strong>Marque os horários indisponíveis</strong> do professor. A ocupação de outros turnos não foi presumida a partir dos PDFs e deve ser informada explicitamente.</p><label>Professor<select id="availabilityTeacher">${state.teachers.map(t=>`<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('')}</select></label><div id="availabilityTable"></div><p class="modal-hint">Todos os professores são avaliados conjuntamente, mesmo em segmentos diferentes.</p>`,form=>{
 const id=$('availabilityTeacher').value;const selected=[...$('availabilityTable').querySelectorAll('input[type=checkbox]:checked')].map(x=>x.value);takeSnapshot(state,'Antes de alterar disponibilidade de '+teacherName(id));state.availability[id]=selected;closeModal();afterEdit('Disponibilidade atualizada. Gere novamente os horários.');
 });
 const draw=()=>{const chosen=$('availabilityTeacher').value;const blocked=new Set(state.availability[chosen]||[]);$('availabilityTable').innerHTML=`<table class="availability-grid"><thead><tr><th>Período</th>${DAYS.map(d=>`<th>${d.split('-')[0]}</th>`).join('')}</tr></thead><tbody>${PERIODS.map((p,i)=>`<tr><th>${i+1}ª<br>${p}</th>${DAYS.map((_,d)=>`<td><input type="checkbox" value="${d}:${i}" ${blocked.has(`${d}:${i}`)?'checked':''} aria-label="${esc(DAYS[d])} ${i+1}ª aula" /></td>`).join('')}</tr>`).join('')}</tbody></table>`};
 $('availabilityTeacher').addEventListener('change',draw);draw();
}
function modalCell(key){const [id,dayRaw,periodRaw]=key.split(':'),day=Number(dayRaw),period=Number(periodRaw),c=getClass(state,id);if(!c||!isActive(c,day,period))return;
 const entries=state.schedule.filter(a=>a.classId===id&&a.day===day&&a.period===period),e=entries[0];
 const choices=allSlots(c).filter(sl=>!(sl.day===day&&sl.period===period)).map(sl=>`<option value="${sl.day}:${sl.period}">${esc(DAYS[sl.day])} · ${sl.period+1}ª aula (${esc(PERIODS[sl.period])})</option>`).join('');
 showModal(`${c.name} · ${DAYS[day]} · ${period+1}ª aula`,`<p class="modal-help">${e?`<strong>${esc(e.subject)}</strong> — ${esc(teacherName(e.teacherId))}`:'Posição vazia ou pendente.'}${entries.length>1?' <strong>Há várias aulas nesta posição; elimine o choque manualmente.</strong>':''}</p>${e?`<label><input type="checkbox" name="locked" ${e.locked?'checked':''}> Fixar esta aula na posição ao gerar novos horários</label>`:''}<label>Trocar com posição da mesma turma<select name="swap"><option value="">Não trocar</option>${choices}</select></label><p class="modal-hint">Uma troca mantém as quantidades de aulas, mas pode gerar choque com docentes de outras turmas. O sistema mostra os conflitos em vermelho.</p>`,form=>{
 if(!e){closeModal();notify('Para preencher esta posição, distribua e gere as aulas pendentes.');return}
 takeSnapshot(state,'Antes de editar posição de '+c.name);
 const swap=String(form.get('swap')||'');e.locked=!!form.get('locked');if(swap){const [d,p]=swap.split(':').map(Number);const other=state.schedule.find(x=>x.classId===id&&x.day===d&&x.period===p);e.day=d;e.period=p;if(other){other.day=day;other.period=period}}
 state.scheduleStatus='rascunho';state.scheduleRevision=state.dataRevision;store();closeModal();renderAll();notify('Aula editada. Os choques são conferidos na grade.');
 });
}
function download(name,content,mime){const b=new Blob([content],{type:mime}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1200)}
function exportCsv(){const header=['Segmento','Turma','Dia','Aula','Horário','Componente','Professor','Situação'];const an=analyzeSchedule(state),rows=[];
 for(const c of state.classes)for(const sl of allSlots(c)){const entries=state.schedule.filter(x=>x.classId===c.id&&x.day===sl.day&&x.period===sl.period);if(entries.length===0)rows.push([segmentLabel(c.segment),c.name,DAYS[sl.day],sl.period+1,PERIODS[sl.period],'','','Pendente']);else for(const e of entries)rows.push([segmentLabel(c.segment),c.name,DAYS[e.day],e.period+1,PERIODS[e.period],e.subject,teacherName(e.teacherId),an.conflicts.has(e.id)?'Conflito':'Atribuída'])}
 const enc=a=>a.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(';');download('expo-horarios-2026.csv','\ufeff'+[header,...rows].map(enc).join('\r\n'),'text/csv;charset=utf-8');notify('CSV exportado.');
}
function exportJson(){download('expo-horarios-backup-2026.json',JSON.stringify(state,null,2),'application/json;charset=utf-8');notify('Backup JSON exportado.');}
function modalHistory(){const history=state.history||[];
 showModal('Histórico e versões',`<p class="modal-help">As últimas 12 cópias anteriores a edições importantes são guardadas aqui. Restaurar substituirá a versão atual.</p>${history.map((h,i)=>`<div class="history-card"><div><strong>${esc(h.label)}</strong><div class="disc-note">${esc(new Date(h.timestamp).toLocaleString('pt-BR'))}</div></div><button type="button" class="smallbtn outline" data-history="${i}">Restaurar</button></div>`).join('')||'<p class="modal-help">Ainda não há versões anteriores.</p>'}`,null,{noSubmit:true,cancelLabel:'Fechar'});
 $('modalBody').querySelectorAll('[data-history]').forEach(btn=>btn.addEventListener('click',()=>{const h=state.history[Number(btn.dataset.history)];if(!confirmAction('Restaurar a versão selecionada?'))return;takeSnapshot(state,'Antes de recuperar versão');for(const key of ['classes','matrix','assignments','schedule','teachers','availability'])if(h[key])state[key]=clone(h[key]);state.dataRevision=h.dataRevision;state.scheduleRevision=h.scheduleRevision;state.scheduleStatus='rascunho';closeModal();store();renderAll();notify('Versão anterior recuperada. Confira a validação.')}));
}
async function generate(){const check=validateSetup(state);if(!check.valid){notify('Corrija as pendências de carga e de professores.');return}
 if(isSolving)return;isSolving=true;renderAll();notify('Conferindo encaixes de professores nos dois segmentos…');
 try{
  const worker=new Worker(new URL('./solver-worker.js',import.meta.url),{type:'module'});
  const response=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{worker.terminate();reject(Error('A busca excedeu o limite de execução.'))},18000);worker.onmessage=e=>{clearTimeout(timer);resolve(e.data);worker.terminate()};worker.onerror=e=>{clearTimeout(timer);reject(Error(e.message||'Falha do gerador'));worker.terminate()};worker.postMessage({state,options:{iterations:110000,maxMs:8000}})});
  if(!response.ok)throw Error(response.error||'Erro na geração');const result=response.result;
  if(result.blocked){notify(result.messages.join(' | '));return}
  takeSnapshot(state,'Antes de gerar novos horários');state.schedule=result.schedule;state.scheduleRevision=state.dataRevision;lastPending=result.pending||[];const grid=analyzeSchedule(state);state.scheduleStatus=result.solved&&grid.complete?'concluido':'rascunho';store();renderAll();notify(result.messages.join(' '));$('horarios').scrollIntoView({behavior:'smooth'});
 }catch(e){notify('Falha ao gerar: '+e.message)}finally{isSolving=false;renderAll()}
}
async function start(){const res=await fetch(new URL('../data/seed.json',import.meta.url));if(!res.ok)throw Error('Não foi possível carregar a base: '+res.status);seed=await res.json();
 try{state=validateImport(JSON.parse(localStorage.getItem(storageKey)||'null'))}catch{state=clone(seed)}
 if(!state)state=clone(seed);
 renderAll();$('saveIndicator').innerHTML='<span class="saved-dot"></span>Salvo neste navegador';
 const configPresent=!!window.EXPO_FIREBASE_CONFIG?.apiKey;
 if(configPresent){$('authButton').hidden=false;cloud=await createCloud(remote=>{try{state=validateImport(remote);store();renderAll();notify('Projeto do Firebase carregado.')}catch(e){notify('Backup remoto inválido: '+e.message)}},(status,connected)=>{$('cloudStatus').textContent=status;$('authButton').textContent=connected?'Sair':'Entrar com Google'},()=>state);
  $('authButton').addEventListener('click',async()=>{try{if(cloud?.getUser())await cloud.logout();else await cloud?.login()}catch(e){notify('Falha no login: '+e.message)}});
 }
 for(const btn of document.querySelectorAll('[data-disc-segment]'))btn.addEventListener('click',()=>{discSegment=btn.dataset.discSegment;document.querySelectorAll('[data-disc-segment]').forEach(x=>x.classList.toggle('active',x===btn));renderDisc()});
 for(const btn of document.querySelectorAll('[data-teacher-segment]'))btn.addEventListener('click',()=>{teacherSegment=btn.dataset.teacherSegment;document.querySelectorAll('[data-teacher-segment]').forEach(x=>x.classList.toggle('active',x===btn));renderTeachers()});
 $('discSearch').addEventListener('input',renderDisc);$('teacherSearch').addEventListener('input',renderTeachers);
 $('discList').addEventListener('click',e=>{const btn=e.target.closest('[data-edit-load]');if(btn)modalLoad(btn.dataset.editLoad)});
 $('teacherList').addEventListener('click',e=>{let btn=e.target.closest('[data-edit-assignment]');if(btn)return modalAssignment(btn.dataset.editAssignment);btn=e.target.closest('[data-edit-teacher]');if(btn)modalTeacher(btn.dataset.editTeacher)});
 $('addTeacherBtn').onclick=()=>modalTeacher();$('addAssignmentBtn').onclick=()=>modalAssignment();$('availabilityBtn').onclick=modalAvailability;$('weeklySlotsBtn').onclick=modalWeeklySlots;
 $('generateBtn').onclick=generate;$('viewGridsBtn').onclick=()=>$('horarios').scrollIntoView({behavior:'smooth'});
 for(const id of ['gridFii','gridEm'])$(id).addEventListener('click',e=>{const el=e.target.closest('[data-cell]');if(el)modalCell(el.dataset.cell)});
 for(const id of ['gridFii','gridEm'])$(id).addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){const el=e.target.closest('[data-cell]');if(el){e.preventDefault();modalCell(el.dataset.cell)}}});
 $('csvBtn').onclick=exportCsv;$('printBtn').onclick=()=>window.print();$('backupBtn').onclick=exportJson;
 $('restoreBtn').onclick=()=>$('backupFile').click();$('backupFile').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{const data=validateImport(JSON.parse(await file.text()));if(!confirmAction('Importar o backup e substituir os dados atuais?'))return;takeSnapshot(state,'Antes de importar backup');state=data;store();renderAll();notify('Backup importado com sucesso.')}catch(err){notify('Arquivo de backup inválido: '+err.message)}finally{e.target.value=''}});
 $('historyBtn').onclick=modalHistory;$('resetBtn').onclick=()=>{if(!confirmAction('Restaurar a matriz e os horários do 4º bimestre de 2026? Seus dados atuais serão substituídos. Exporte um backup antes.'))return;state=clone(seed);lastPending=[];store();renderAll();notify('Matriz de referência restaurada.')} ;
}
start().catch(e=>{$('alerts').innerHTML=`<div class="alert error">Erro ao inicializar: ${esc(e.message)}. Abra este projeto em um servidor local (veja README).</div>`;$('saveIndicator').textContent='Falha ao carregar';console.error(e)});
