// Sincronização opcional. Sem configuração, o aplicativo permanece totalmente local.
export async function createCloud(onRemote,onStatus,getState){
 const config=window.EXPO_FIREBASE_CONFIG;
 if(!config?.apiKey||!config?.projectId)return null;
 try{
  const [{initializeApp},{getAuth,GoogleAuthProvider,signInWithPopup,signOut,onAuthStateChanged},{getFirestore,doc,getDoc,setDoc}]=await Promise.all([
   import('https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js'),
   import('https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js'),
   import('https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js')]);
  const app=initializeApp(config),auth=getAuth(app),db=getFirestore(app);let user=null;let timer=null;
  const save=()=>{if(!user)return;clearTimeout(timer);timer=setTimeout(async()=>{try{
    await setDoc(doc(db,'users',user.uid,'projects','expo-horarios'),{state:JSON.stringify(getState()),lastWrite:new Date().toISOString()});onStatus('Sincronizado no Firebase',true);
    }catch(e){onStatus('Erro de sincronização: '+e.message,false)}},1000)};
  onAuthStateChanged(auth,async u=>{user=u; if(!u){onStatus('Firebase configurado · desconectado',false);return;}onStatus(`Conectado: ${u.email}`,true);
    try{const snap=await getDoc(doc(db,'users',u.uid,'projects','expo-horarios'));
       if(snap.exists()){
         const remote=JSON.parse(snap.data().state);
         if(confirm('Existe um projeto salvo no Firebase nesta conta. Deseja carregá-lo neste navegador? Cancelar mantém a versão local, sem substituí-la.'))onRemote(remote);
       }else save();
    }catch(e){onStatus('Falha ao carregar Firebase: '+e.message,false)}
  });
  return {getUser:()=>user,login:()=>signInWithPopup(auth,new GoogleAuthProvider()),logout:()=>signOut(auth),save};
 }catch(e){onStatus('Firebase não disponível: '+e.message,false);return null;}
}
