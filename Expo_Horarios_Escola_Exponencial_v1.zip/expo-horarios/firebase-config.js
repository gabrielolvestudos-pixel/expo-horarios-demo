// Copie as credenciais públicas de configuração do projeto Firebase aqui.
// Não habilite escrita anônima no Firestore. Leia README.md.
window.EXPO_FIREBASE_CONFIG = null;
// Exemplo (substituir pelos dados reais do console Firebase):
// window.EXPO_FIREBASE_CONFIG = { apiKey:'...',authDomain:'...',projectId:'...',appId:'...' };
