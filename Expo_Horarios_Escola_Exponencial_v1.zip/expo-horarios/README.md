# Expo Horários — Escola Exponencial

Aplicativo web estático para **planejar, conferir e gerar horários escolares** com uma única checagem de conflito docente para Fundamental II e Ensino Médio. Desenvolvido em HTML, CSS e JavaScript ES Modules, sem etapa de build e sem bibliotecas obrigatórias. A integração com Firebase Authentication/Firestore é opcional.

## O que esta versão já faz

- Pré-carrega os **305 encontros semanais do 4º bimestre de 2026** de 11 turmas e 22 professores, transcritos na planilha `Matriz_Escolar_Exponencial_2026.xlsx` da conversa anterior.
- Mantém **Fundamental II** (5 turmas × 25 aulas) e **Ensino Médio** (6 turmas × 30 aulas) em quadros distintos, mas **confere choques em conjunto**.
- Exibe disciplinas por segmento e os indicadores **Total**, **Atribuídas** e **Restantes**. Aulas excedentes geram saldo negativo e bloqueiam a geração.
- **Editar carga horária** por disciplina e por turma; prévia do impacto nos saldos, sem ajustar cotas docentes silenciosamente.
- **Cadastrar/editar docentes** (um cadastro por pessoa) e **incluir/editar/excluir atribuições** específicas por turma, disciplina e segmento.
- **Ajustar os períodos ativos por dia e turma** (0 a 6 períodos/dia nesta versão), inclusive quando mudar o regimento. As novas capacidades precisam fechar com a matriz.
- Cadastrar **indisponibilidades docentes explícitas**. Não deduz disponibilidade a partir de horários vazios dos PDFs.
- **Gerar horários** sem sobreposição automática. O gerador parte da grade existente, tenta realocação por trocas dentro de cada turma, preserva aulas travadas e verifica todas as turmas. Se não consegue preencher, retorna **rascunho com pendências em branco**; não afirma inviabilidade sem prova.
- Aulas editadas/importadas com choque aparecem em **vermelho**, incluindo duas células de um mesmo professor ocupado simultaneamente.
- Trocas manuais entre períodos da mesma turma; opção de travar uma aula no período antes de tentar gerar.
- Backup JSON, importação, versões anteriores, impressão dos quadros e exportação CSV.
- Salvamento automático no navegador (`localStorage`); sincronização opcional **por conta** via Firebase Authentication com Google e Firestore.

## Como abrir localmente

Execute no diretório do projeto:

```bash
python3 -m http.server 8000
```

Abra `http://localhost:8000` no navegador. É necessário um servidor HTTP porque o aplicativo usa ES Modules e `fetch` para carregar `data/seed.json`. Abrir `index.html` via `file://` pode falhar.

Para rodar os testes automatizados, com Node.js 20 ou superior:

```bash
npm test
```

## GitHub Pages (hospedagem gratuita)

1. Crie um repositório e envie o conteúdo da pasta (o arquivo `index.html` deve ficar na raiz).
2. Em **Settings → Pages**, selecione **Deploy from a branch**, branch `main`, pasta `/ (root)`.
3. Acesse o endereço publicado. **Sem Firebase configurado**, os dados permanecem apenas no navegador e dispositivo que os editou; faça backups em JSON.

A matriz embutida inclui nomes de professores e horários. Em um repositório **público**, qualquer pessoa pode acessar esses dados: obtenha autorização institucional e restrinja/remova dados antes da publicação se necessário. GitHub Pages, na modalidade gratuita usual, não oferece autenticação que impeça a leitura do próprio `seed.json`.

## Firebase Hosting + Firestore (opcional)

1. Crie o projeto no [console Firebase](https://console.firebase.google.com/).
2. Ative **Authentication → Sign-in method → Google**; registre o domínio usado em **Authorized domains**.
3. Crie um banco **Cloud Firestore**. **Não habilite regras públicas**.
4. Em **Project settings → Your apps → Web app**, copie os valores do SDK para `firebase-config.js`, substituindo `null` por:

```js
window.EXPO_FIREBASE_CONFIG = {
  apiKey: '...',
  authDomain: 'seu-projeto.firebaseapp.com',
  projectId: 'seu-projeto',
  appId: '...'
};
```

5. Instale o Firebase CLI (`npm install -g firebase-tools`) e faça `firebase login`, `firebase use --add` e `firebase deploy --only hosting,firestore:rules`.
6. O projeto usa `users/{uid}/projects/expo-horarios` como documento privado. Cada pessoa só enxerga **a própria versão**. Para uma grade compartilhada com coordenação, será necessário implementar papéis, permissões e colaboração multiusuário. Não conceda a todos os usuários autenticados acesso irrestrito à base escolar.

As chaves do objeto `firebaseConfig` são identificadores públicos do aplicativo, **não credenciais de administrador**. Nunca coloque credenciais de serviço, tokens privados ou arquivos `.env` com segredos no repositório.

## Validações e limites desta primeira entrega

- A planilha de referência foi **inferida dos horários enviados**, não da matriz oficial do regimento. Confirmar cargas e disciplinas com a coordenação. Foram mantidos separados `Biologia A`, `Química A`, `C. Física`, `C. Química`, `C. Biológica`, `LIV` e `E. Alimentos` como aparecem nos originais.
- Os nomes originais **Sidimar**, **Josoel**, **Camile** e **Camyla** foram preservados, sem fundir pessoas diferentes.
- Não foram importados horários do **Fundamental I**, turnos da tarde, salas compartilhadas, distâncias de deslocamento, preferências de aulas duplas ou limites diários por disciplina; exigem dados e regras adicionais.
- O gerador atual é um **algoritmo heurístico local** de troca de aulas e não um resolvedor CP-SAT exaustivo. Pode não encontrar uma solução mesmo que ela exista; identifica isso como **busca sem solução encontrada**, não como inviabilidade. Para casos de muitas restrições, a próxima etapa é integrar um resolvedor especializado (por exemplo, Timefold/OR-Tools) no backend ou numa função de servidor.
- A 6ª aula do Fundamental II é **fora da grade por padrão**, não um horário pendente. O Ensino Médio usa seis aulas diárias.
- Em mudanças no total da semana, configure os dias/períodos e confira os totais. Esta versão oferece até **seis períodos por dia** com horários predefinidos (07h–12h30). Períodos adicionais ou horários diferentes exigirão ampliação da configuração.
- Os backups JSON mantêm nomes e horários docentes. Guarde-os em local autorizado.
- **Não foi feito deploy real** neste trabalho porque não há acesso autorizado ao seu projeto do Firebase nem às credenciais do GitHub.

## Arquivos principais

| Arquivo | Finalidade |
|---|---|
| `index.html` | Interface e seções da página |
| `styles.css` | Identidade visual azul escuro e responsividade |
| `data/seed.json` | Matriz, professores, cotas e quadro-base reais de 2026 |
| `js/core.js` | Cálculos de demanda, validações, choques e pendências |
| `js/scheduler.js` | Algoritmo de geração e busca conjunta |
| `js/solver-worker.js` | Execução da busca fora da thread principal |
| `js/app.js` | Telas, formulários, eventos, relatórios, backup |
| `js/firebase-sync.js` | Firebase Google Auth / Firestore por conta |
| `firestore.rules` | Regras de segurança privadas |
| `tests/scheduler.test.mjs` | Testes automatizados |

**Entrega:** primeira versão funcional para revisão e testes pelo Astra/Work. Recomenda-se rodar os testes automatizados e testar alterações de cargas, indisponibilidades, bloqueios e geração em cenários reais antes de uso oficial.
